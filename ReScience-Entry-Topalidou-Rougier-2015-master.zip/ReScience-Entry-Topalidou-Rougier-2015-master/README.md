
\[Re\] Interaction between cognitive and motor cortico-basal ganglia loops during decision making: a computational study, M. Topalidou and N.P. Rougier, Re**Science**, 2015.
  
**A reference implementation of** *Interaction between cognitive and motor cortico-basal ganglia loops during decision making: a computational study*, M. Guthrie, A. Leblois, A. Garenne, and T. Boraud, Journal of Neurophysiology, 109, 2013.

**Keywords**: Neuroscience, Basal Ganglia, Python
